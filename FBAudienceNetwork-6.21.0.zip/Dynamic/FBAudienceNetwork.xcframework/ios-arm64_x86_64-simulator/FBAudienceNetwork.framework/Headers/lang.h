// (c) Meta Platforms, Inc. and affiliates. Confidential and proprietary.

#ifndef XPLAT_COMMON_LANG_LANG_H
#define XPLAT_COMMON_LANG_LANG_H

#include <lang/switch.h>

#endif // XPLAT_COMMON_LANG_LANG_H
